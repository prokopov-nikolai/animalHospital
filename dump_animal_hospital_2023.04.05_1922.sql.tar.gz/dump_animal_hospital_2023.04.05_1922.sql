-- MySQL dump 10.19  Distrib 10.3.32-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: animal_hospital
-- ------------------------------------------------------
-- Server version	10.3.32-MariaDB-0ubuntu0.20.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ah_cron_task`
--

DROP TABLE IF EXISTS `ah_cron_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_cron_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `method` varchar(500) NOT NULL,
  `plugin` varchar(50) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 1,
  `count_run` int(11) NOT NULL DEFAULT 0,
  `period_run` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `date_run_last` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `count_run` (`count_run`),
  KEY `state` (`state`),
  KEY `plugin` (`plugin`),
  KEY `method` (`method`(255)),
  KEY `period_run` (`period_run`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_cron_task`
--

LOCK TABLES `ah_cron_task` WRITE;
/*!40000 ALTER TABLE `ah_cron_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `ah_cron_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_media`
--

DROP TABLE IF EXISTS `ah_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `target_id` int(11) unsigned NOT NULL,
  `target_type` varchar(50) NOT NULL,
  `target_tmp` varchar(50) DEFAULT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_name` varchar(500) NOT NULL,
  `file_size` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `date_add` datetime NOT NULL,
  `data` text NOT NULL,
  `sort` tinyint(2) unsigned DEFAULT 0,
  `original_hash` text DEFAULT NULL,
  `mirrored_hash` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_add` (`date_add`),
  KEY `f_media_target_type_target_id_index` (`target_type`,`target_id`),
  KEY `file_size` (`file_size`),
  KEY `height` (`height`),
  KEY `target_type` (`target_type`),
  KEY `type` (`type`),
  KEY `user_id` (`user_id`),
  KEY `width` (`width`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_media`
--

LOCK TABLES `ah_media` WRITE;
/*!40000 ALTER TABLE `ah_media` DISABLE KEYS */;
INSERT INTO `ah_media` VALUES (1,1,1,1,'user_photo',NULL,'[relative]/uploads/media/user_photo/2023/04/05/14/5f1c456554114cf9cadd.jpg','1',135477,1050,700,'2023-04-05 14:11:34','a:1:{s:11:\"image_sizes\";a:1:{i:0;a:4:{s:1:\"w\";s:3:\"100\";s:1:\"h\";N;s:4:\"crop\";b:0;s:1:\"r\";N;}}}',0,'ffffffffffffffffffffffffffffffffffffffffffffffffffdfffffffcffff3ff8fff83ff0fff27ff07fb67fe07ff6fff1fe6fffd138ffeb1011e80b1001e000000000002c0400000c18000004800000020000080000000000000080000003800000058000000180000009000000cf8000000e00000c3c04000e70000046700','fffffffffffffffffffffffffffffffffffffffffffffffffffffbffcffff3ffc1fff1ffe4fff0ffe6dfe0fff6ffe07fff67f8ff7ff1c8bf0178808d0078008d000000000002034000018300000012000000040000000001100000001c0000001a00000018000000090000001f3000000700000003c3000000e7000200e62000'),(6,1,1,1,'pet_photo',NULL,'[relative]/uploads/media/pet_photo/2023/04/05/17/63f3b04a4f6e98d83953.jpg','2',328645,1024,682,'2023-04-05 17:59:00','a:1:{s:11:\"image_sizes\";a:2:{i:0;a:4:{s:1:\"w\";s:3:\"100\";s:1:\"h\";N;s:4:\"crop\";b:0;s:1:\"r\";N;}i:1;a:4:{s:1:\"w\";N;s:1:\"h\";s:2:\"50\";s:4:\"crop\";b:0;s:1:\"r\";N;}}}',0,'00080007000000010000000000030000000100000000000004000000020000000100000000020000001200000000c0020011000086019800007fbf000073bf400be3ffc08de27fe07fc47ff3ffe01fffffe07f7fdfe1fdff0f83ffff7d03ffff7dc3fffef183fffff987fffff9cfdfffffefffffffdfffffffcffdff3fcfbfff','e000100080000000000000000000c0000000800000000000000000200000004000000080000040000000480040030000000088000019806100fdfe0002fdce0003ffc7d007fe47b1cffe23fefff807fffefe07ffffbf87fbffffc1f0ffffc0be7fffc3beffffc18fffffe19ffffbf39ffffff7fffffffbffffbff3fffffdf3fc'),(7,1,1,3,'pet_photo',NULL,'[relative]/uploads/media/pet_photo/2023/04/05/18/bd4653dc8ae5e5069ff7.jpg','2',328645,1024,682,'2023-04-05 18:20:20','a:1:{s:11:\"image_sizes\";a:2:{i:0;a:4:{s:1:\"w\";s:3:\"100\";s:1:\"h\";N;s:4:\"crop\";b:0;s:1:\"r\";N;}i:1;a:4:{s:1:\"w\";N;s:1:\"h\";s:2:\"50\";s:4:\"crop\";b:0;s:1:\"r\";N;}}}',0,'00080007000000010000000000030000000100000000000004000000020000000100000000020000001200000000c0020011000086019800007fbf000073bf400be3ffc08de27fe07fc47ff3ffe01fffffe07f7fdfe1fdff0f83ffff7d03ffff7dc3fffef183fffff987fffff9cfdfffffefffffffdfffffffcffdff3fcfbfff','e000100080000000000000000000c0000000800000000000000000200000004000000080000040000000480040030000000088000019806100fdfe0002fdce0003ffc7d007fe47b1cffe23fefff807fffefe07ffffbf87fbffffc1f0ffffc0be7fffc3beffffc18fffffe19ffffbf39ffffff7fffffffbffffbff3fffffdf3fc'),(8,1,1,4,'pet_photo',NULL,'[relative]/uploads/media/pet_photo/2023/04/05/18/32fe558812090f3d7d33.jpg','5',175717,983,737,'2023-04-05 18:37:59','a:1:{s:11:\"image_sizes\";a:2:{i:0;a:4:{s:1:\"w\";s:3:\"100\";s:1:\"h\";N;s:4:\"crop\";b:0;s:1:\"r\";N;}i:1;a:4:{s:1:\"w\";N;s:1:\"h\";s:2:\"50\";s:4:\"crop\";b:0;s:1:\"r\";N;}}}',0,'c02b60e0c002e0e0c001f0c4cc12f9e35e02f9c71f01ffc75fa1ffc7dfa1ffe7ff81fdcfffc1ffefffe7fdcfffebfdeeffe1fdeeffe1f1efffe9f1eeffedb0e7ffed91e7fbef81cfffef81e7fbeba7e6ebe3efe6c1e1efe600000320000002200400000007000000078004000f800fe00e1ffc011fbff8013fffffc03fffff00','0706d40307074003230f8003c79f4833e39f407ae3ff80f8e3ff85fae7ff85fbf3bf81fff7ff83fff3bfe7ff77bfd7ff77bf87fff78f87ff778f97ffe70db7ffe789b7fff381f7dfe781f7ff67e5d7df67f7c7d767f7878304c000000440000000000020000000e0002001e007f001f0803ff870801ffdf803fffffc00fffffc'),(9,1,1,5,'user_photo',NULL,'[relative]/uploads/media/user_photo/2023/04/05/18/f90c5e96fc0cb5cec7cd.jpg','802e1ea7b59b90e8933afc15b99d03b4',233611,2000,1000,'2023-04-05 18:53:30','a:1:{s:11:\"image_sizes\";a:1:{i:0;a:4:{s:1:\"w\";s:3:\"100\";s:1:\"h\";N;s:4:\"crop\";b:0;s:1:\"r\";N;}}}',0,'fffe3ffffffe3ffffffc3ffffff82ffffff00ffffff007ffffe007ffffc407ffffc403ffffc403ffffc003ffff8007ffff8003ffff0003ffff8503ffff8303ffff0303ffff0303ffff0003ffff8007ffff0007fffe0003fffc0001fffe0081fffc0001fffc0001fffc0401fffc0001fffc0001fff00001fff00001ffe00801ff','fffc7ffffffc7ffffffc3ffffff41ffffff00fffffe00fffffe007ffffe023ffffc023ffffc023ffffc003ffffe001ffffc001ffffc000ffffc0a1ffffc0c1ffffc0c0ffffc0c0ffffc000ffffe001ffffe000ffffc0007fff80003fff81007fff80003fff80003fff80203fff80003fff80003fff80000fff80000fff801007'),(10,1,1,5,'pet_photo',NULL,'[relative]/uploads/media/pet_photo/2023/04/05/18/f916093a4a860cb6cd5d.jpg','6 (1-я копия)',143847,1024,683,'2023-04-05 18:53:53','a:1:{s:11:\"image_sizes\";a:1:{i:0;a:4:{s:1:\"w\";s:3:\"100\";s:1:\"h\";N;s:4:\"crop\";b:0;s:1:\"r\";N;}}}',0,'000000ff000001ff800003ffe00003ffe40067ffe400fffff801fffffe01ffffff83fffffffff7ffffffffffffffffffffffffff7ffffff801017ff0000007e000000000be408000fffff800fffbfe408603fc7dfc09f07ffc81e1ff000001ff0000087f0000003f0000803f0000003f040c003f000000030000000000000000','ff000000ff800000ffc00001ffc00007ffe60027ffff0027ffff801fffff807fffffc1ffffefffffffffffffffffffffffffffff1ffffffe0ffe808007e00000000000000001027d001fffff027fdfffbe3fc061fe0f903fff87813fff800000fe100000fc000000fc010000fc000000fc003020c00000000000000000000000');
/*!40000 ALTER TABLE `ah_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_notify_task`
--

DROP TABLE IF EXISTS `ah_notify_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_notify_task` (
  `notify_task_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(30) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `notify_subject` varchar(200) DEFAULT NULL,
  `notify_text` text DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `notify_task_status` tinyint(2) unsigned DEFAULT NULL,
  PRIMARY KEY (`notify_task_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_notify_task`
--

LOCK TABLES `ah_notify_task` WRITE;
/*!40000 ALTER TABLE `ah_notify_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `ah_notify_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_pet`
--

DROP TABLE IF EXISTS `ah_pet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_pet` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_create` timestamp NULL DEFAULT current_timestamp(),
  `nickname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `species` enum('cat','dog') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ah_pet_ah_user_id_fk` (`user_id`),
  CONSTRAINT `ah_pet_ah_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `ah_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_pet`
--

LOCK TABLES `ah_pet` WRITE;
/*!40000 ALTER TABLE `ah_pet` DISABLE KEYS */;
INSERT INTO `ah_pet` VALUES (1,'2023-04-05 14:57:13','рой','','dog',1),(3,'2023-04-05 15:20:20','Рокки','фывфыв','dog',1),(4,'2023-04-05 15:37:59','мич','фываыфв','cat',1),(5,'2023-04-05 15:53:53','Марис','','cat',5);
/*!40000 ALTER TABLE `ah_pet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_plugin_migration`
--

DROP TABLE IF EXISTS `ah_plugin_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_plugin_migration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `version` varchar(50) NOT NULL,
  `date_create` datetime NOT NULL,
  `file` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file` (`file`(255)),
  KEY `code` (`code`),
  KEY `version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_plugin_migration`
--

LOCK TABLES `ah_plugin_migration` WRITE;
/*!40000 ALTER TABLE `ah_plugin_migration` DISABLE KEYS */;
/*!40000 ALTER TABLE `ah_plugin_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_plugin_version`
--

DROP TABLE IF EXISTS `ah_plugin_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_plugin_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `version` varchar(50) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_plugin_version`
--

LOCK TABLES `ah_plugin_version` WRITE;
/*!40000 ALTER TABLE `ah_plugin_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `ah_plugin_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_reminder`
--

DROP TABLE IF EXISTS `ah_reminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_reminder` (
  `code` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `date_used` datetime DEFAULT '0000-00-00 00:00:00',
  `date_expire` datetime NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`code`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_reminder`
--

LOCK TABLES `ah_reminder` WRITE;
/*!40000 ALTER TABLE `ah_reminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `ah_reminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_right`
--

DROP TABLE IF EXISTS `ah_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_right` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_c8_right_key` (`key`),
  KEY `ah_right_ah_right_id_fk` (`parent_id`),
  CONSTRAINT `ah_right_ah_right_id_fk` FOREIGN KEY (`parent_id`) REFERENCES `ah_right` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Справочник прав';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_right`
--

LOCK TABLES `ah_right` WRITE;
/*!40000 ALTER TABLE `ah_right` DISABLE KEYS */;
INSERT INTO `ah_right` VALUES (1,'Пользователи','1_users',NULL,2),(2,'Редактировать','2_users_edit',1,1),(3,'Редактировать права','3_users_edit_rights',1,2),(4,'Питомцы','4_pets',NULL,1),(5,'Редактировать','5_pets_edit',4,1);
/*!40000 ALTER TABLE `ah_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_session`
--

DROP TABLE IF EXISTS `ah_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_session` (
  `key` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_create` varchar(40) NOT NULL,
  `ip_last` varchar(40) NOT NULL,
  `date_create` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_last` datetime NOT NULL,
  `date_close` datetime DEFAULT NULL,
  `extra` text DEFAULT NULL,
  PRIMARY KEY (`key`),
  KEY `date_last` (`date_last`),
  KEY `date_close` (`date_close`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_session`
--

LOCK TABLES `ah_session` WRITE;
/*!40000 ALTER TABLE `ah_session` DISABLE KEYS */;
INSERT INTO `ah_session` VALUES ('09dccdeef57cd444bd58079c606504df',1,'127.0.0.1','127.0.0.1','2023-04-05 08:48:39','2023-04-05 18:53:05',NULL,'{\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/106.0.0.0 YaBrowser\\/22.11.3.832 (beta) Yowser\\/2.5 Safari\\/537.36\"}'),('111858a5aac192c0761da33498366a21',1,'127.0.0.1','127.0.0.1','2023-04-05 08:45:21','2023-04-05 08:45:21',NULL,'{\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/106.0.0.0 YaBrowser\\/22.11.3.832 (beta) Yowser\\/2.5 Safari\\/537.36\"}');
/*!40000 ALTER TABLE `ah_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_storage`
--

DROP TABLE IF EXISTS `ah_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL,
  `value` mediumtext NOT NULL,
  `instance` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_instance` (`key`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_storage`
--

LOCK TABLES `ah_storage` WRITE;
/*!40000 ALTER TABLE `ah_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ah_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_user`
--

DROP TABLE IF EXISTS `ah_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fio` varchar(150) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `phone_dop` varchar(11) DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  `date_create` datetime NOT NULL,
  `date_activate` datetime DEFAULT NULL,
  `ip_create` varchar(40) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `activate` tinyint(1) NOT NULL DEFAULT 0,
  `activate_key` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mail` (`email`),
  KEY `password` (`password`),
  KEY `activate_key` (`activate_key`),
  KEY `active` (`active`),
  KEY `activate` (`activate`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_user`
--

LOCK TABLES `ah_user` WRITE;
/*!40000 ALTER TABLE `ah_user` DISABLE KEYS */;
INSERT INTO `ah_user` VALUES (1,'Николай','79040335233@ya.ru','79040335233','78888999999','4297f44b13955235245b2497399d7a93','2023-04-05 08:42:25',NULL,'127.0.0.1',1,1,1,NULL),(4,'Nikolay','79040335231@ya.ru','79109129129','','123456','2023-04-05 18:39:30',NULL,'127.0.0.1',1,0,0,NULL),(5,'Мария','79040335238@ya.ru','78888888888','','123456','2023-04-05 18:53:30',NULL,'127.0.0.1',1,0,1,NULL);
/*!40000 ALTER TABLE `ah_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ah_user_rights`
--

DROP TABLE IF EXISTS `ah_user_rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ah_user_rights` (
  `user_id` int(11) unsigned NOT NULL,
  `right_id` int(11) unsigned NOT NULL,
  KEY `ah_user_rights_ah_right_id_fk` (`right_id`),
  KEY `ah_user_rights_ah_user_id_fk` (`user_id`),
  CONSTRAINT `ah_user_rights_ah_right_id_fk` FOREIGN KEY (`right_id`) REFERENCES `ah_right` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ah_user_rights_ah_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `ah_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ah_user_rights`
--

LOCK TABLES `ah_user_rights` WRITE;
/*!40000 ALTER TABLE `ah_user_rights` DISABLE KEYS */;
INSERT INTO `ah_user_rights` VALUES (1,1),(1,3),(1,2),(1,4),(1,5);
/*!40000 ALTER TABLE `ah_user_rights` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-05 19:22:19
